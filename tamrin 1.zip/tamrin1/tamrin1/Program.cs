﻿using System;
using System.Diagnostics;

class Program
{
    static void Main()
    {
        // ایجاد یک پروسه
        Process myProcess = new Process();

        // تنظیم مسیر فایل اجرایی برای پروسه
        myProcess.StartInfo.FileName = "notepad.exe";

        // ایجاد پروسه
        myProcess.Start();

        // کیل کردن پروسه
        myProcess.Kill();

        // لیست کردن تمام پروسه‌ها
        Process[] allProcesses = Process.GetProcesses();
        foreach (Process process in allProcesses)
        {
            Console.WriteLine($"Process Name: {process.ProcessName}, ID: {process.Id}");
        }

        // بدست آوردن پروسه‌های والدین
        Process currentProcess = Process.GetCurrentProcess();
        Console.WriteLine($"Parent Process Name: {currentProcess.Parent().ProcessName}, ID: {currentProcess.Parent().Id}");
    }
}